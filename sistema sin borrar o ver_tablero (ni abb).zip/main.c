#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include "strutil.h"
#include "hash.h"
#include "heap.h"

enum datos{
	flight_number,
	airline,
	origin_airport,
	destination_airport,
	tail_number,
	priority,
	date,
	departure_delay,
	air_time,
	cancelled,
};

int lenstrv(char **strv){
	if (!strv) return -1;
	int len = 0;
	for(int i = 0; strv[i]; i++) len++;
	return len;
}

int heap_max_cmp(const void* a,const void* b){
	char** vuelo1 = (char**)a;
	char** vuelo2 = (char**)b;
	int prioridad1 = atoi(vuelo1[priority]);
	int prioridad2 = atoi(vuelo2[priority]);
	if(prioridad1>prioridad2) return 1;
	else if(prioridad1<prioridad2) return -1;
	else{
		int codigo1 = atoi(vuelo1[flight_number]);
		int codigo2 = atoi(vuelo2[flight_number]);
		if(codigo1 > codigo2) return -1;
		return 1;
	}
}

int heap_min_cmp(const void* a,const void* b){
	if(heap_max_cmp(a,b)>0) return -1;
	return 1;
}

void destruir_dato_wrapper(void* dato){
	free_strv((char**)dato);
}

bool info_vuelo(char** comandos, hash_t* hash){
	if ( lenstrv(comandos) != 2 )return false;
	if(hash_cantidad(hash)==0)return false;
	char** vuelo = hash_obtener(hash, comandos[1]);
	if(vuelo==NULL)return false;
	for(int i=0;i<10;i++){
		fprintf(stdout,"%s",vuelo[i]);
		if(i<9)fprintf(stdout," ");
	}
	return true;
}

bool agregar_archivo(char **comandos, hash_t* hash){
	if(lenstrv(comandos)!=2){
		return false;
	}
	FILE* archivo = fopen(comandos[1],"r");
	if(archivo==NULL){
		return false;
	}
	char* linea = NULL;
	size_t cant = 0;
	while(getline(&linea,&cant,archivo)>0){
		char** vuelo = split(linea,',');
		if(!hash_guardar(hash,vuelo[flight_number],vuelo))return false;
		if(!hash_pertenece(hash,vuelo[flight_number]))return false;
	}
	free(linea);
	fclose(archivo);
	return true;
}

bool prioridad_vuelos(char **comandos,hash_t* hash){
	if ( lenstrv(comandos) != 2 )return false;
	int K = atoi(comandos[1]);
	heap_t* heap = heap_crear(heap_min_cmp);
	if(heap==NULL) return false;
	hash_iter_t* iter = hash_iter_crear(hash);
	if(iter==NULL){
		heap_destruir(heap,NULL);
		return false;
	}
	//Crea un heap de mínimos de tamaño k con los primeros k elementos.
	for(int i = 0;i<K;i++){
		if(!hash_iter_al_final(iter)){
			char** vuelo = hash_obtener(hash,hash_iter_ver_actual(iter));
			heap_encolar(heap,vuelo);
			hash_iter_avanzar(iter);
		}
	}
	//Recorre todos los elementos para obtener los k elementos con mayor prioridad.
	while(!hash_iter_al_final(iter)){
		char** vuelo = hash_obtener(hash,hash_iter_ver_actual(iter));
		if(heap_max_cmp(vuelo,heap_ver_max(heap))>0){
			heap_desencolar(heap);
			heap_encolar(heap,hash_obtener(hash,hash_iter_ver_actual(iter)));
		}
		hash_iter_avanzar(iter);
	}
	hash_iter_destruir(iter);
	heap_t* heap_max = heap_crear(heap_max_cmp);
	if(heap_max==NULL){
		heap_destruir(heap,NULL);
		return false;
	}
	//Vacía los k elementos con mayor prioridad en un heap de máximos
	//obteniendo el orden mayor a menor.
	while(!heap_esta_vacio(heap)){
		heap_encolar(heap_max,heap_desencolar(heap));
	}
	heap_destruir(heap,NULL);
	//Muestra los k elementos obtenidos por salida estandar de mayor a menor.
	while(!heap_esta_vacio(heap_max)){
		char** vuelo = heap_desencolar(heap_max);
		fprintf(stdout,"%s - %s\n",vuelo[priority],vuelo[flight_number]);
	}
	heap_destruir(heap_max,NULL);
	return true;
}

bool ejecutar_operacion(char **comandos,hash_t* hash){
	if ( strcmp ( comandos[0],"agregar_archivo") == 0 ) return agregar_archivo(comandos,hash); 
	
	else if ( strcmp ( comandos[0],"info_vuelo") == 0 ) return info_vuelo(comandos,hash);
	
	else if ( strcmp ( comandos[0],"prioridad_vuelos") == 0 ) return prioridad_vuelos(comandos,hash);
	
	else return false;
	
}

int main(){
	size_t cap = 0;
	char *linea = NULL;
	hash_t* hash = hash_crear(destruir_dato_wrapper);
	
	while( getline ( &linea, &cap, stdin ) != EOF ){
		size_t len_linea = strlen(linea);
		if(linea[len_linea-1]=='\n')linea[len_linea-1]='\0';
		char **comandos = split(linea,' ');
		bool ok = ejecutar_operacion(comandos,hash);
		if (!ok) fprintf(stderr,"Error en el comando %s\n",comandos[0]);
		else fprintf(stdout,"OK\n");
		free_strv(comandos);
	} 
	hash_destruir(hash);
	free(linea);
	return 0;
}
