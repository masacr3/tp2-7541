#include <stdio.h>
#include <stdlib.h>
#include "hash.h"
#include "lista.h"

bool info_vuelo(char** comandos, hash_t* hash);
