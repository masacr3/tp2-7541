#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include "time.h"
#include "strutil.h"
#include "hash.h"
#include "abb.h"
#include "funciones_auxiliares.h"
#include "agregar_archivo_.h"
#include "info_vuelos_.h"
#include "prioridades_vuelos.h"


bool ejecutar_operacion(char **comandos,hash_t* hash,abb_t* abb){
	if ( strcmp ( comandos[0],"agregar_archivo") == 0 ) return agregar_archivo(comandos,hash,abb); 
	
	else if ( strcmp ( comandos[0],"info_vuelo") == 0 ) return info_vuelo(comandos,hash);
	
	else if ( strcmp ( comandos[0],"prioridad_vuelos") == 0 ) return prioridad_vuelos(comandos,hash);
	
	//else if ( strcmp ( comandos[0],"ver_tablero") == 0 ) return ver_tablero(comandos,abb);
	
	else return false;
	
}

int main(){
	size_t cap = 0;
	char *linea = NULL;
	hash_t* hash = hash_crear(destruir_dato_wrapper);
	abb_t* abb = abb_crear(abb_cmp,NULL);
	while( getline ( &linea, &cap, stdin ) != EOF ){
		size_t len_linea = strlen(linea);
		if(linea[len_linea-1]=='\n')linea[len_linea-1]='\0';
		char **comandos = split(linea,' ');
		bool ok = ejecutar_operacion(comandos,hash,abb);
		if (!ok) fprintf(stderr,"Error en el comando %s\n",comandos[0]);
		else fprintf(stdout,"OK\n");
		free_strv(comandos);
	} 
	hash_destruir(hash);
	free(linea);
	return 0;
}
