#include <stdio.h>
#include "hash.h"
#include "lista.h"
#include "abb.h"
#include <stdbool.h>
#include <stdlib.h>

bool agregar_archivo(char **comandos, hash_t* hash,abb_t* abb);
