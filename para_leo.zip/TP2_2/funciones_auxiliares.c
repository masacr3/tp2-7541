#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include "tiempo.h"
#include "strutil.h"
#include "hash.h"
#include "heap.h"
#include "funciones_auxiliares.h"
#define FLIGHT_NUMBER 0
#define DATE 6
#define PRIORITY 5


int heap_cmp(const void* a,const void* b){
	char** dato1 = (char**) a; 
	char** dato2 = (char**) b;
	int p_1 = atoi(dato1[PRIORITY]);
	int p_2 = atoi(dato2[PRIORITY]);
	if(p_1 == p_2){
		int n_1 = atoi(dato1[FLIGHT_NUMBER]);
		int n_2 = atoi(dato2[FLIGHT_NUMBER]);
		if(n_1 < n_2 ) return 1;
		if(n_1 > n_2 ) return -1;
		return 0;
	}
	if(p_1 < p_2) return 1;
	return -1;
}

char * empaquetar(char **datos){
  if(!datos) return NULL;

  char **paquete = malloc ( sizeof(char*) * 3);

  if ( !paquete) return NULL;

  paquete[0] = datos[6]; //date
  paquete[1] = datos[0]; //flight_number
  paquete[2] = NULL;


  return join(paquete,',');
}

//suponemos que a , b tienen datos
int abb_cmp(const char *a, const char *b){
  char **tiempo1 = split(a,',');
  char **tiempo2 = split(b,',');

  time_t t1 = iso8601_to_time(tiempo1[0]); //tiempos
  time_t t2 = iso8601_to_time(tiempo2[0]); //tiempos

  if (difftime(t2,t1) > 0){
    free_strv(tiempo1);
    free_strv(tiempo2);
    return 1;
  }
  if (difftime(t2,t1) < 0){
    free_strv(tiempo1);
    free_strv(tiempo2);
    return -1;
  }

  if (strcmp(tiempo1[1],tiempo2[1]) < 0){
    free_strv(tiempo1);
    free_strv(tiempo2);
    return 1;
  }
  if (strcmp(tiempo1[1],tiempo2[1]) > 0 ){
    free_strv(tiempo1);
    free_strv(tiempo2);
    return -1;
  }

  free_strv(tiempo1);
  free_strv(tiempo2);

  return 0;
}

//Devuelve el largo de un vector de cadenas.
int lenstrv(char **strv){
	if (!strv) return -1;
	int len = 0;
	for(int i = 0; strv[i]; i++) len++;
	return len;
}

//Función de destrucción de dato para tdas abb y hash.
void destruir_dato_wrapper(void* dato){
	free_strv((char**)dato);
}
