#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include "strutil.h"
#include "hash.h"
#include "heap.h"
#include "funciones_auxiliares.h"

bool prioridad_vuelos(char **comandos,hash_t* hash);
