#ifndef FUNCIONES_H
#define FUNCIONES_H
#include <string.h>
#include "strutil.h"
#include <time.h>

int heap_cmp(const void* a,const void* b);
char * empaquetar(char **datos);
int abb_cmp(const char *a, const char *b);
int lenstrv(char **strv);
void destruir_dato_wrapper(void* dato);

#endif
